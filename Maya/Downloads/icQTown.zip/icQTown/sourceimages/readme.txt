These images are only meant as a guide for what textures are needed for QTown to work properly and to show what the naming convention for these files is.

Replace these files with whatever is suitable for your project and place these in your project sourceimages directory or any other texture location.