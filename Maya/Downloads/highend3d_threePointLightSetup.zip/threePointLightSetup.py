#
# Copyright (C) by Adrian Sochacki, 2018. All rights reserved.
#
# Description: Automatically sets up a three-point-light setup to test render your object very easily
#
# How to use: Select one or more objects and run the script
#
# Tested in Maya 2017, 2018
#
# Version: 1.1.0
#

import maya.cmds as cmds
import math
import sys

#Instant three point light setup for your selection:
def threePointLightSetup():
	sel = cmds.ls(sl=True)

	if len(sel) == 0:
		sys.exit('Please select first an object')

	bBox = cmds.exactWorldBoundingBox(sel)

	keyLight = cmds.shadingNode('areaLight', asLight=True)
	fillLight = cmds.shadingNode('areaLight', asLight=True)
	rimLight = cmds.shadingNode('areaLight', asLight=True)
	ground = cmds.polyPlane(object = True, subdivisionsX = 3, subdivisionsY = 3)

	lights = [keyLight, fillLight, rimLight]
	cmds.select(keyLight)
	cmds.select(fillLight, add = True)
	cmds.select(rimLight, add = True)

	lightContainer = cmds.group()

	v1 = [bBox[0], bBox[1], bBox[2]]
	v2 = [bBox[3], bBox[4], bBox[5]]
	v3 = [v2[0]- v1[0], v2[1]-v1[1], v2[2]-v1[2]]
	vLength = math.sqrt(v3[0]**2 + v3[1]**2 + v3[2]**2)
	rounded = math.ceil(vLength)
	scaleFactor = rounded/7.0

	cmds.xform(keyLight, absolute = True, translation = [4, bBox[4] / scaleFactor * 0.75, -3], rotation = [-24, 130, 0])
	cmds.xform(fillLight, absolute = True, translation = [3, bBox[4] / scaleFactor * 1.6, 5], rotation = [-18, 35, 0])
	cmds.xform(rimLight, absolute = True, translation = [-6, bBox[4] / scaleFactor * 0.5, 1], rotation = [0, -77, 0], scale = [2, 2, 2])
	cmds.xform(ground, absolute = True, scale = [2.5 * bBox[4] + bBox[4] * 0.8, 1, 2.5 * bBox[4]+ bBox[4] * 0.8])

	transValue = cmds.xform(sel, query = True, translation = True, absolute = True)
	cmds.xform(ground, absolute = True, translation = [transValue[0], bBox[1], transValue[2]])

	if bBox[3] > bBox[5]:
		cmds.xform(ground, absolute = True, scale = [bBox[3] * 3.1, 0, bBox[3] * 3.1])

	if bBox[5] > bBox[3]:
		cmds.xform(ground, absolute = True, scale = [bBox[5] * 3.1, 0, bBox[5] * 3.1])

	if bBox[3] == bBox[5]:
		cmds.xform(ground, absolute = True, scale = [bBox[5] * 3.1, 0, bBox[5] * 3.1])


	for light in lights:
		shape = cmds.listRelatives(light, shapes = True)
		cmds.setAttr(str(shape[0]) + ".aiExposure", 2)
		cmds.setAttr(str(shape[0]) + ".intensity", 20 * scaleFactor * scaleFactor/2)
		cmds.setAttr(str(shape[0]) + ".decayRate", 2)

	keyLight = cmds.rename(keyLight, 'keyLight_LGT')
	fillLight = cmds.rename(fillLight, 'fillLight_LGT')
	rimLight = cmds.rename(rimLight, 'rimLight_LGT')
	ground = cmds.rename(ground[0], 'floor_GEO')
	lightContainer = cmds.rename(lightContainer, 'threePointLightingSetup_GRP')

	if not cmds.about(batch = True):
		cmds.scale(scaleFactor, scaleFactor, scaleFactor, lightContainer)
		cmds.parent(ground, lightContainer)

	if len(sel) == 1:
		sys.stdout.write("Now your object is lit by a three point light setup.\n")
	else:
		sys.stdout.write("Now your objects are lit by a three point light setup.\n")

threePointLightSetup()