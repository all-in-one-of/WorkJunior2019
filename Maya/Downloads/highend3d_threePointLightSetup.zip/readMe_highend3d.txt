Thank you for using my script, I hope it will help you!

Please use the bug and report function on highend3d.

Still have trouble in Maya? Maybe one of my other products can help you:
https://www.highend3d.com/shop/schocki?sort=newest