Make sure all the scripts are in the maya scripts folder.

Copy the code in ToolboxFin.py to the script runner in Maya
Or add that script to what a button calls

 and you're good to go.